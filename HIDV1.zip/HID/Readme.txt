LibUX.zip
	- has
		-- UI
		-- Online Book Micro service developed by using Node JS
			-- It needs to run along with Spring rest service

gs-rest-service-new.zip
	- has
		-- Rest service. It has been upgraded with Online MS.

Everything tested working fine

End Points
Rest service
http://localhost:8080/allBooks
http://localhost:9999/onlineBooks
http://localhost:8080/getBook?bookID=1
http://localhost:8080/getBookContent?bookID=1
http://localhost:8080/login?key=passkey
http://localhost:8080/addBook?bookID=10&bookTitle=Title10&bookContent=Content10
http://localhost:8080/updateBook?bookID=1&bookNewTitle=TitleOne&bookNewContent=ContentOne
http://localhost:8080/deleteBook?bookID=10

Online MS end point
http://localhost:9999/onlineBooks